package com.example.util

import android.content.Context
import android.provider.Settings
import com.example.model.GestureType
import com.example.model.JarvisAction

data class InterpretationResult(
    val action: JarvisAction,
    val spokenResponse: String,
    val actionLog: String
)

object JarvisIntelligence {

    fun interpret(input: String, context: Context, phoneControlEnabled: Boolean): InterpretationResult {
        val query = input.trim().lowercase()

        // 1. Phone Control Master Switch Commands
        if (query.contains("phone control on") || query.contains("phone control chalu") ||
            query.contains("full control on") || query.contains("phone ka control le lo") ||
            query.contains("control on karo") || query.contains("pure phone ka control") ||
            query.contains("control activate")) {
            return InterpretationResult(
                action = JarvisAction.ControlStateToggle(true),
                spokenResponse = "Autonomous phone control mode activate kar diya gaya hai, sir! Ab pure phone ka direct control mere paas hai.",
                actionLog = "Master Protocol: Autonomous Phone Control ENGAGED"
            )
        }

        if (query.contains("phone control off") || query.contains("phone control band") ||
            query.contains("disable control") || query.contains("control wapas lo") ||
            query.contains("control band karo")) {
            return InterpretationResult(
                action = JarvisAction.ControlStateToggle(false),
                spokenResponse = "Phone control disengage ho gaya hai, sir. Manual control wapas restore kar diya gaya hai.",
                actionLog = "Master Protocol: Phone Control DISENGAGED"
            )
        }

        // 2. Flashlight / Torch
        if (query.contains("torch on") || query.contains("flashlight on") ||
            query.contains("light on") || query.contains("torch jalao") ||
            query.contains("batti jalao") || query.contains("light chalu") ||
            query.contains("flashlight jalao") || query.contains("torch chalao")) {
            return InterpretationResult(
                action = JarvisAction.ToggleFlashlight(true),
                spokenResponse = "Ji sir, flashlight on kar di hai.",
                actionLog = "Hardware Action: Flashlight set to ON"
            )
        }

        if (query.contains("torch off") || query.contains("flashlight off") ||
            query.contains("light off") || query.contains("torch band") ||
            query.contains("batti bujhao") || query.contains("light band karo") ||
            query.contains("flashlight band")) {
            return InterpretationResult(
                action = JarvisAction.ToggleFlashlight(false),
                spokenResponse = "Flashlight band kar di gayi hai, sir.",
                actionLog = "Hardware Action: Flashlight set to OFF"
            )
        }

        // 3. Navigation Gestures (Home, Back, Recents, Notifications, Lock Screen)
        if (query.contains("home screen") || query.contains("go home") ||
            query.contains("home par jao") || query.contains("home jao") ||
            query == "home" || query.contains("home kholo") || query.contains("app band karo")) {
            return InterpretationResult(
                action = JarvisAction.ExecuteGesture(GestureType.HOME),
                spokenResponse = "Ji sir, Home screen par ja rahe hain.",
                actionLog = "Autonomous Action: Gesture HOME"
            )
        }

        if (query.contains("go back") || query.contains("piche jao") ||
            query.contains("back karo") || query.contains("back jao") || query == "back") {
            return InterpretationResult(
                action = JarvisAction.ExecuteGesture(GestureType.BACK),
                spokenResponse = "Back kar diya hai, sir.",
                actionLog = "Autonomous Action: Gesture BACK"
            )
        }

        if (query.contains("recent apps") || query.contains("multitasking") ||
            query.contains("recents") || query.contains("recent app dikhao") ||
            query.contains("background apps") || query.contains("recent kholo")) {
            return InterpretationResult(
                action = JarvisAction.ExecuteGesture(GestureType.RECENTS),
                spokenResponse = "Recent apps aur running tasks open kar diye hain, sir.",
                actionLog = "Autonomous Action: Gesture RECENTS"
            )
        }

        if (query.contains("notification") || query.contains("notifications") ||
            query.contains("shade") || query.contains("message check karo") ||
            query.contains("notification kholo") || query.contains("notification dikhao")) {
            return InterpretationResult(
                action = JarvisAction.ExecuteGesture(GestureType.NOTIFICATIONS),
                spokenResponse = "Notification panel niche kar diya hai, sir.",
                actionLog = "Autonomous Action: Gesture NOTIFICATIONS"
            )
        }

        if (query.contains("lock screen") || query.contains("screen lock") ||
            query.contains("phone lock") || query.contains("lock karo") ||
            query.contains("screen band karo") || query.contains("phone band karo")) {
            return InterpretationResult(
                action = JarvisAction.ExecuteGesture(GestureType.LOCK_SCREEN),
                spokenResponse = "Phone screen ko lock aur secure kiya ja raha hai, sir.",
                actionLog = "Autonomous Action: Gesture LOCK_SCREEN"
            )
        }

        if (query.contains("screenshot") || query.contains("screen capture") ||
            query.contains("photo khincho")) {
            return InterpretationResult(
                action = JarvisAction.ExecuteGesture(GestureType.SCREENSHOT),
                spokenResponse = "Screenshot capture kar liya gaya hai, sir.",
                actionLog = "Autonomous Action: Screenshot captured"
            )
        }

        // 4. Volume Controls
        if (query.contains("volume up") || query.contains("volume badhao") ||
            query.contains("aawaz badhao") || query.contains("aawaz tej") ||
            query.contains("increase volume") || query.contains("sound badhao")) {
            return InterpretationResult(
                action = JarvisAction.ChangeVolume(true),
                spokenResponse = "Volume badha diya gaya hai, sir.",
                actionLog = "Hardware Action: Volume increased (+)"
            )
        }

        if (query.contains("volume down") || query.contains("volume kam karo") ||
            query.contains("aawaz kam karo") || query.contains("decrease volume") ||
            query.contains("sound kam karo") || query.contains("aawaz dheere")) {
            return InterpretationResult(
                action = JarvisAction.ChangeVolume(false),
                spokenResponse = "Volume kam kar diya gaya hai, sir.",
                actionLog = "Hardware Action: Volume decreased (-)"
            )
        }

        // 5. Battery Status
        if (query.contains("battery") || query.contains("charging") ||
            query.contains("power status") || query.contains("charge kitna") ||
            query.contains("battery kitni")) {
            val (lvl, charging) = DeviceController.getBatteryInfo(context)
            val state = if (charging) "charging par laga hua hai" else "battery par chal raha hai"
            return InterpretationResult(
                action = JarvisAction.QueryBattery,
                spokenResponse = "Sir, aapke phone ki battery $lvl percent hai aur phone $state.",
                actionLog = "Diagnostic: Battery $lvl% (Charging: $charging)"
            )
        }

        // 6. Settings Shortcuts
        if (query.contains("wifi") || query.contains("wi-fi") || query.contains("hotspot")) {
            return InterpretationResult(
                action = JarvisAction.OpenSetting("Wi-Fi Settings", Settings.ACTION_WIFI_SETTINGS),
                spokenResponse = "Wi-Fi network settings open kar raha hoon, sir.",
                actionLog = "System Action: Open Wi-Fi Settings"
            )
        }

        if (query.contains("bluetooth") || query.contains("bt settings")) {
            return InterpretationResult(
                action = JarvisAction.OpenSetting("Bluetooth Settings", Settings.ACTION_BLUETOOTH_SETTINGS),
                spokenResponse = "Bluetooth settings open kar di hai, sir.",
                actionLog = "System Action: Open Bluetooth Settings"
            )
        }

        if (query.contains("open settings") || query.contains("settings kholo") ||
            query == "settings" || query.contains("phone setting")) {
            return InterpretationResult(
                action = JarvisAction.OpenSetting("Device Settings", Settings.ACTION_SETTINGS),
                spokenResponse = "Phone ki main settings open kar raha hoon, sir.",
                actionLog = "System Action: Open Settings"
            )
        }

        // 7. Web Search
        if (query.startsWith("search for ") || query.startsWith("search ") ||
            query.startsWith("google ") || query.contains("search karo") ||
            query.contains("google par search") || query.contains("pata karo")) {
            val term = query.replace("search for", "")
                .replace("search karo", "")
                .replace("google par search", "")
                .replace("search", "")
                .replace("google", "")
                .replace("pata karo", "")
                .trim()
            val effectiveTerm = if (term.isBlank()) "Latest technology news" else term
            return InterpretationResult(
                action = JarvisAction.SearchWeb(effectiveTerm),
                spokenResponse = "Ji sir, '$effectiveTerm' ke baare mein Google par search kiya ja raha hai.",
                actionLog = "Network Action: Web search '$effectiveTerm'"
            )
        }

        // 8. Call / Dial
        if (query.startsWith("call ") || query.startsWith("dial ") || query.contains("call karo") || query.contains("phone lagao")) {
            val number = query.filter { it.isDigit() }
            val dialTarget = if (number.isNotBlank()) number else "198"
            return InterpretationResult(
                action = JarvisAction.DialNumber(dialTarget),
                spokenResponse = "Ji sir, $dialTarget par call dialer khol raha hoon.",
                actionLog = "Telephony Action: Dial target $dialTarget"
            )
        }

        // 9. Launch Any Installed App
        val openAppTrigger = query.startsWith("open ") || query.startsWith("kholo ") ||
                query.startsWith("chalao ") || query.endsWith("kholo") ||
                query.endsWith("chalao") || query.endsWith("open karo") ||
                query.contains("app kholo") || query.contains("launch ")

        val candidateAppName = query
            .replace("open karo", "")
            .replace("open", "")
            .replace("kholo", "")
            .replace("chalao", "")
            .replace("launch", "")
            .replace("app", "")
            .trim()

        if (candidateAppName.isNotBlank() && (openAppTrigger || candidateAppName.length in 2..20)) {
            val matchedApp = DeviceController.findAppByName(context, candidateAppName)
            if (matchedApp != null) {
                return InterpretationResult(
                    action = JarvisAction.LaunchApp(matchedApp.label, matchedApp.packageName),
                    spokenResponse = "Ji sir! ${matchedApp.label} open kar diya hai.",
                    actionLog = "App Launcher: Launching ${matchedApp.label} (${matchedApp.packageName})"
                )
            }
        }

        // 10. Hindi Conversational & Jarvis Persona Replies
        val conversationalRules = listOf(
            listOf("sun rahe ho", "meri aawaz", "sunai de raha") to
                "Haan sir! Main bilkul clearly sun raha hoon. Boliye, main aapke liye kya karu?",
            listOf("tum kaun ho", "kaun ho tum", "who are you", "aap kaun ho") to
                "Main JARVIS hoon, sir! Aapka apna personal AI assistant. Main aapke phone ko fully control kar sakta hoon aur aapke har aadesh ka palan karta hoon.",
            listOf("kya kar sakte ho", "kya kam kar sakte ho", "tum kya kar sakte ho", "what can you do") to
                "Sir, main aapke phone ka koi bhi app open kar sakta hoon, torch on/off kar sakta hoon, volume control, phone lock, home/recents gestures, battery status, web search aur aapse baatein kar sakta hoon!",
            listOf("kaise ho", "kya haal hai", "how are you", "sab theek") to
                "Main bilkul fit aur 100% operational hoon, sir! Aap bataiye, aaj kya plan hai?",
            listOf("kuch bolo", "kuch bolo na", "bolo", "kuch to bolo", "speak") to
                "Ji sir, main hazir hoon! All systems nominal hain. Aap koi bhi app kholne ko boliye ya phone command dijiye, main turant kar dunga.",
            listOf("kya chal raha hai", "kya ho raha hai", "whats up", "what's up") to
                "Sir, phone systems monitor kar raha hoon aur aapke agle command ka wait kar raha hoon!",
            listOf("namaste", "pranam", "namaskar") to
                "Namaste sir! Jarvis online hai. Aaj aapke phone mein kya task execute karna hai?",
            listOf("hey jarvis", "hai jarvis", "char mis", "charmis", "hello jarvis", "hi jarvis", "jarvis", "zarvis", "sarvis", "wake up") to
                "Haan sir, main active hoon! Boliye, kya kaam hai?",
            listOf("hello", "hi", "hey") to
                "Haan sir, main active hoon! Boliye, kya kaam hai?",
            listOf("joke sunao", "chutkula", "hasao") to
                "Ek joke suniye sir: Ek baar ek phone doosre phone se bola, 'Bhai teri battery itni jaldi down kyu hoti hai?' Doosra bola, 'Kyunki main pure din reels dekhne mein busy rehta hoon!'",
            listOf("dhanyawad", "thank you", "thanks", "shukriya") to
                "Aapka bahut-bahut swagat hai sir! Aapki madad karke mujhe hamesha khushi hoti hai.",
            listOf("good morning", "shubh prabhat") to
                "Good morning sir! Have a wonderful day ahead. All systems are operational.",
            listOf("good night", "shubh ratri", "so jao") to
                "Good night sir! Sweet dreams. Main background mein aapke phone ki safety maintain karunga.",
            listOf("iron man", "tony stark") to
                "Mr. Stark ko salaam, sir! Arc reactor core 100% capacity par function kar raha hai."
        )

        for ((keywords, reply) in conversationalRules) {
            if (keywords.any { query.contains(it) }) {
                return InterpretationResult(
                    action = JarvisAction.Conversational(reply),
                    spokenResponse = reply,
                    actionLog = "Dialogue Protocol: Replied in Hindi"
                )
            }
        }

        // Fallback intelligent Hindi response
        val fallback = if (phoneControlEnabled) {
            "Ji sir, maine aapki baat sun li: \"$input\". Phone control active hai. Agar koi app kholna hai, flashlight chalani hai ya settings dekhni hai to boliye!"
        } else {
            "Ji sir, maine aapki baat sun li: \"$input\". Main aapki seva mein hazir hoon. Phone ka full control dene ke liye 'Phone Control' switch ON kar lijiye."
        }

        return InterpretationResult(
            action = JarvisAction.Conversational(fallback),
            spokenResponse = fallback,
            actionLog = "Cognitive Engine: Responded in Hindi -> \"$input\""
        )
    }
}
