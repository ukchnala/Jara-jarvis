package com.example.model

data class InstalledAppInfo(
    val label: String,
    val packageName: String,
    val isSystem: Boolean = false
)
