package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.ChatMessage
import com.example.model.GestureType
import com.example.model.InstalledAppInfo
import com.example.model.JarvisAction
import com.example.service.JarvisAccessibilityService
import com.example.service.JarvisBackgroundService
import com.example.util.DeviceController
import com.example.util.JarvisIntelligence
import com.example.util.VoiceManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class JarvisTab {
    CORE_HUD,
    VOICE_CHAT,
    PHONE_CONTROL,
    SYSTEM_LOGS
}

class JarvisViewModel(application: Application) : AndroidViewModel(application) {

    private val context = application.applicationContext

    private val _phoneControlEnabled = MutableStateFlow(false)
    val phoneControlEnabled: StateFlow<Boolean> = _phoneControlEnabled.asStateFlow()

    private val _isAccessibilityGranted = MutableStateFlow(false)
    val isAccessibilityGranted: StateFlow<Boolean> = _isAccessibilityGranted.asStateFlow()

    private val _isBackgroundListeningEnabled = MutableStateFlow(false)
    val isBackgroundListeningEnabled: StateFlow<Boolean> = _isBackgroundListeningEnabled.asStateFlow()

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _systemLogs = MutableStateFlow<List<String>>(emptyList())
    val systemLogs: StateFlow<List<String>> = _systemLogs.asStateFlow()

    private val _batteryLevel = MutableStateFlow(85)
    val batteryLevel: StateFlow<Int> = _batteryLevel.asStateFlow()

    private val _isCharging = MutableStateFlow(false)
    val isCharging: StateFlow<Boolean> = _isCharging.asStateFlow()

    private val _isFlashlightOn = MutableStateFlow(false)
    val isFlashlightOn: StateFlow<Boolean> = _isFlashlightOn.asStateFlow()

    private val _installedApps = MutableStateFlow<List<InstalledAppInfo>>(emptyList())
    val installedApps: StateFlow<List<InstalledAppInfo>> = _installedApps.asStateFlow()

    private val _activeTab = MutableStateFlow(JarvisTab.CORE_HUD)
    val activeTab: StateFlow<JarvisTab> = _activeTab.asStateFlow()

    private val _voiceAutoSpeakEnabled = MutableStateFlow(true)
    val voiceAutoSpeakEnabled: StateFlow<Boolean> = _voiceAutoSpeakEnabled.asStateFlow()

    private var voiceManager: VoiceManager? = null

    val isListening: StateFlow<Boolean>
        get() = voiceManager?.isListening ?: MutableStateFlow(false).asStateFlow()

    val isSpeaking: StateFlow<Boolean>
        get() = voiceManager?.isSpeaking ?: MutableStateFlow(false).asStateFlow()

    val rmsDb: StateFlow<Float>
        get() = voiceManager?.rmsDb ?: MutableStateFlow(0f).asStateFlow()

    init {
        initVoice()
        refreshSystemStatus()
        loadInstalledApps()

        // Initial system log
        addSystemLog("SYSTEM: J.A.R.V.I.S. Core Online (Hindi Neural Voice Active)")
        addSystemLog("DIAGNOSTIC: Hardware controls and Accessibility bridge ready")

        // Initial welcoming message in natural Hindi
        _messages.value = listOf(
            ChatMessage(
                text = "Namaste Sir! Main JARVIS hoon. Pure phone ka control lene ke liye taiyar. Aap mujhse voice ya chat mein kuch bhi pooch sakte hain!",
                isJarvis = true
            )
        )

        // Observe accessibility status
        viewModelScope.launch {
            JarvisAccessibilityService.isRunning.collect { running ->
                _isAccessibilityGranted.value = running || JarvisAccessibilityService.isAccessibilityEnabled(context)
                if (running) {
                    addSystemLog("ACCESSIBILITY: Jarvis Automation Bridge Connected")
                }
            }
        }

        // Observe background listening service status
        viewModelScope.launch {
            JarvisBackgroundService.isRunning.collect { running ->
                _isBackgroundListeningEnabled.value = running
            }
        }
    }

    private fun initVoice() {
        voiceManager = VoiceManager(context) { recognizedText ->
            processUserCommand(recognizedText, isVoice = true)
        }
        voiceManager?.onSpeechErrorCallback = { errorMsg ->
            addSystemLog("VOICE_EVENT: $errorMsg")
        }
    }

    fun selectTab(tab: JarvisTab) {
        _activeTab.value = tab
    }

    fun refreshSystemStatus() {
        val (level, charging) = DeviceController.getBatteryInfo(context)
        _batteryLevel.value = level
        _isCharging.value = charging
        _isAccessibilityGranted.value = JarvisAccessibilityService.isAccessibilityEnabled(context)
        _isFlashlightOn.value = DeviceController.isFlashlightActive()
        _isBackgroundListeningEnabled.value = JarvisBackgroundService.isRunning.value
    }

    fun loadInstalledApps() {
        viewModelScope.launch(Dispatchers.IO) {
            val apps = DeviceController.getInstalledApps(context)
            _installedApps.value = apps
            addSystemLog("PACKAGE_SCAN: Found ${apps.size} installed applications ready for execution")
        }
    }

    fun setPhoneControlEnabled(enabled: Boolean) {
        _phoneControlEnabled.value = enabled
        DeviceController.vibrate(context, 70)
        if (enabled) {
            addSystemLog("ALERT: Autonomous Phone Control Mode ENGAGED")
            speak("Autonomous phone control activate kar diya hai, sir. Ab main aapke phone ka koi bhi app open kar sakta hoon aur gestures execute kar sakta hoon.")
            _messages.value = _messages.value + ChatMessage(
                text = "Autonomous Phone Control mode activate ho gaya hai! JARVIS ke paas pure phone ka control aa gaya hai.",
                isJarvis = true,
                actionSummary = "Phone Control Master Switch: ACTIVE"
            )
        } else {
            addSystemLog("STATUS: Autonomous Phone Control Mode Disengaged")
            speak("Phone control band kar diya gaya hai, sir.")
            _messages.value = _messages.value + ChatMessage(
                text = "Phone control mode deactivate ho gaya hai. Manual control restore kar diya gaya hai.",
                isJarvis = true,
                actionSummary = "Phone Control Master Switch: INACTIVE"
            )
        }
    }

    fun toggleBackgroundListening(enabled: Boolean) {
        _isBackgroundListeningEnabled.value = enabled
        DeviceController.vibrate(context, 50)
        if (enabled) {
            JarvisBackgroundService.start(context)
            addSystemLog("SERVICE: Background Wake-Word ('Jarvis') Listener STARTED")
            speak("Background listening activate ho gayi hai, sir! Chahe app band ho ya screen lock ho, 'Jarvis' bolte hi main activate ho jaunga.")
            _messages.value = _messages.value + ChatMessage(
                text = "Background listening active: Jarvis background mein 'Jarvis' wake-word monitor kar raha hai.",
                isJarvis = true,
                actionSummary = "Background Wake-Word: ON"
            )
        } else {
            JarvisBackgroundService.stop(context)
            addSystemLog("SERVICE: Background Wake-Word Listener STOPPED")
            speak("Background listening band kar di gayi hai, sir.")
            _messages.value = _messages.value + ChatMessage(
                text = "Background listening deactivated.",
                isJarvis = true,
                actionSummary = "Background Wake-Word: OFF"
            )
        }
    }

    fun onReactorCoreClicked() {
        DeviceController.vibrate(context, 60)
        if (isListening.value) {
            stopListening()
        } else {
            val prompt = "Haan sir, main active hoon! Boliye, kya kaam hai?"
            speak(prompt)
            _messages.value = _messages.value + ChatMessage(
                text = prompt,
                isJarvis = true
            )
            startListening()
        }
    }

    fun triggerWakeWordTest() {
        DeviceController.vibrate(context, 70)
        val reply = "Haan sir, main active hoon! Boliye, kya kaam hai?"
        speak(reply)
        _messages.value = _messages.value + ChatMessage(
            text = reply,
            isJarvis = true,
            actionSummary = "Wake Word: 'Hey Jarvis' Verified"
        )
        addSystemLog("WAKE_TEST: 'Hey Jarvis' triggered -> Responded in Hindi")
    }

    fun toggleVoiceAutoSpeak() {
        _voiceAutoSpeakEnabled.value = !_voiceAutoSpeakEnabled.value
    }

    fun startListening() {
        voiceManager?.startListening()
    }

    fun stopListening() {
        voiceManager?.stopListening()
    }

    fun speak(text: String) {
        if (_voiceAutoSpeakEnabled.value) {
            voiceManager?.speak(text)
        }
    }

    fun stopSpeaking() {
        voiceManager?.stopSpeaking()
    }

    fun toggleFlashlight() {
        val success = DeviceController.toggleFlashlight(context)
        if (success) {
            val state = DeviceController.isFlashlightActive()
            _isFlashlightOn.value = state
            val msg = if (state) "Torch jala di hai, sir" else "Torch band kar di hai, sir"
            addSystemLog("HARDWARE: $msg")
            speak(msg)
        }
    }

    fun launchAppByPackage(packageName: String, label: String) {
        addSystemLog("APP_EXEC: Launching $label ($packageName)")
        val success = DeviceController.launchApp(context, packageName)
        if (success) {
            speak("Ji sir, $label khol raha hoon.")
            _messages.value = _messages.value + ChatMessage(
                text = "Successfully opened $label application.",
                isJarvis = true,
                actionSummary = "Launched $label"
            )
        } else {
            addSystemLog("APP_EXEC_ERROR: Unable to launch $packageName")
        }
    }

    fun executeGesture(gesture: GestureType) {
        val actionName = gesture.name
        val success = when (gesture) {
            GestureType.HOME -> JarvisAccessibilityService.performHome()
            GestureType.BACK -> JarvisAccessibilityService.performBack()
            GestureType.RECENTS -> JarvisAccessibilityService.performRecents()
            GestureType.NOTIFICATIONS -> JarvisAccessibilityService.performNotifications()
            GestureType.QUICK_SETTINGS -> JarvisAccessibilityService.performQuickSettings()
            GestureType.LOCK_SCREEN -> JarvisAccessibilityService.performLockScreen()
            GestureType.SCREENSHOT -> JarvisAccessibilityService.performScreenshot()
        }

        if (success) {
            addSystemLog("GESTURE_SUCCESS: Executed $actionName")
            DeviceController.vibrate(context, 40)
        } else {
            addSystemLog("GESTURE_PENDING: Accessibility service required for $actionName. Tap 'Setup Access'.")
            if (!_isAccessibilityGranted.value) {
                JarvisAccessibilityService.openAccessibilitySettings(context)
            }
        }
    }

    fun openAccessibilitySettings() {
        JarvisAccessibilityService.openAccessibilitySettings(context)
    }

    fun processUserCommand(input: String, isVoice: Boolean = false) {
        if (input.isBlank()) return

        // Add user message
        _messages.value = _messages.value + ChatMessage(
            text = input,
            isJarvis = false,
            isVoice = isVoice
        )

        viewModelScope.launch {
            delay(100)
            val result = JarvisIntelligence.interpret(input, context, _phoneControlEnabled.value)

            // Add action log
            addSystemLog("EXEC: ${result.actionLog}")

            // Execute the resolved action
            executeResolvedAction(result.action)

            // Add Jarvis response
            _messages.value = _messages.value + ChatMessage(
                text = result.spokenResponse,
                isJarvis = true,
                actionSummary = result.actionLog,
                isVoice = isVoice
            )

            // Speak reply in natural Hindi
            speak(result.spokenResponse)
        }
    }

    private fun executeResolvedAction(action: JarvisAction) {
        when (action) {
            is JarvisAction.ControlStateToggle -> {
                setPhoneControlEnabled(action.enable)
            }
            is JarvisAction.LaunchApp -> {
                DeviceController.launchApp(context, action.packageName)
            }
            is JarvisAction.ToggleFlashlight -> {
                DeviceController.toggleFlashlight(context, action.turnOn)
                _isFlashlightOn.value = DeviceController.isFlashlightActive()
            }
            is JarvisAction.ChangeVolume -> {
                val newLevel = DeviceController.adjustVolume(context, action.increase)
                addSystemLog("AUDIO: Volume adjusted to $newLevel%")
            }
            is JarvisAction.ExecuteGesture -> {
                executeGesture(action.gestureType)
            }
            is JarvisAction.OpenSetting -> {
                DeviceController.openSystemSetting(context, action.actionIntent)
            }
            is JarvisAction.QueryBattery -> {
                refreshSystemStatus()
            }
            is JarvisAction.SearchWeb -> {
                DeviceController.searchWeb(context, action.query)
            }
            is JarvisAction.OpenUrl -> {
                DeviceController.openUrl(context, action.url)
            }
            is JarvisAction.DialNumber -> {
                DeviceController.dialNumber(context, action.number)
            }
            is JarvisAction.Conversational -> {
                // Handled in message posting
            }
        }
    }

    fun addSystemLog(log: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        _systemLogs.value = listOf("[$time] $log") + _systemLogs.value.take(150)
    }

    fun clearChat() {
        _messages.value = listOf(
            ChatMessage(
                text = "Chat history clear ho gayi hai sir. Main aapki nayi command ke liye taiyar hoon!",
                isJarvis = true
            )
        )
    }

    override fun onCleared() {
        super.onCleared()
        voiceManager?.destroy()
    }
}
