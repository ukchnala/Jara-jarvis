package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Accessibility
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.BrightnessMedium
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ViewCarousel
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.GestureType
import com.example.model.InstalledAppInfo
import com.example.ui.components.CyberCard
import com.example.ui.components.CyberStatusBadge
import com.example.ui.theme.JarvisAmber
import com.example.ui.theme.JarvisBorderGlow
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.JarvisDarkSurface
import com.example.ui.theme.JarvisDarkSurfaceVariant
import com.example.ui.theme.JarvisDeepDark
import com.example.ui.theme.JarvisNeonGreen
import com.example.ui.theme.JarvisTextPrimary
import com.example.ui.theme.JarvisTextSecondary

@Composable
fun PhoneControlScreen(
    phoneControlEnabled: Boolean,
    isAccessibilityGranted: Boolean,
    installedApps: List<InstalledAppInfo>,
    onTogglePhoneControl: (Boolean) -> Unit,
    onOpenAccessibilitySettings: () -> Unit,
    onExecuteGesture: (GestureType) -> Unit,
    onLaunchApp: (String, String) -> Unit,
    onOpenSetting: (String, String) -> Unit
) {
    var appSearchQuery by remember { mutableStateOf("") }

    val filteredApps = remember(installedApps, appSearchQuery) {
        if (appSearchQuery.isBlank()) {
            installedApps
        } else {
            installedApps.filter {
                it.label.contains(appSearchQuery, ignoreCase = true) ||
                it.packageName.contains(appSearchQuery, ignoreCase = true)
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(JarvisDeepDark)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. MASTER PHONE CONTROL HERO SWITCH
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("full_phone_control_banner"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (phoneControlEnabled) JarvisDarkSurfaceVariant else JarvisDarkSurface
                ),
                border = BorderStroke(
                    width = if (phoneControlEnabled) 2.dp else 1.dp,
                    color = if (phoneControlEnabled) JarvisNeonGreen else JarvisBorderGlow
                )
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "PHONE CONTROL MODE",
                                    color = JarvisTextPrimary,
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontFamily = FontFamily.Monospace,
                                    letterSpacing = 1.sp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                CyberStatusBadge(
                                    label = if (phoneControlEnabled) "ACTIVE" else "STANDBY",
                                    isActive = phoneControlEnabled,
                                    activeColor = JarvisNeonGreen
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (phoneControlEnabled)
                                    "JARVIS has full administrative control of device"
                                else
                                    "Activate to grant JARVIS complete device control",
                                color = if (phoneControlEnabled) JarvisNeonGreen else JarvisTextSecondary,
                                fontSize = 12.sp
                            )
                        }

                        Switch(
                            checked = phoneControlEnabled,
                            onCheckedChange = onTogglePhoneControl,
                            modifier = Modifier.testTag("phone_control_screen_switch"),
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.Black,
                                checkedTrackColor = JarvisNeonGreen,
                                uncheckedThumbColor = JarvisTextSecondary,
                                uncheckedTrackColor = JarvisDarkSurfaceVariant
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Accessibility Bridge status & setup button
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(JarvisDeepDark)
                            .border(1.dp, if (isAccessibilityGranted) JarvisNeonGreen.copy(alpha = 0.4f) else JarvisAmber.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Accessibility,
                                contentDescription = null,
                                tint = if (isAccessibilityGranted) JarvisNeonGreen else JarvisAmber,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Android Accessibility Service",
                                    color = JarvisTextPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = if (isAccessibilityGranted)
                                        "Connected: JARVIS can perform gestures & navigate"
                                    else
                                        "Permission needed for autonomous screen navigation",
                                    color = if (isAccessibilityGranted) JarvisNeonGreen else JarvisAmber,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Button(
                            onClick = onOpenAccessibilitySettings,
                            modifier = Modifier
                                .testTag("setup_accessibility_service_btn")
                                .padding(start = 8.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isAccessibilityGranted) JarvisDarkSurfaceVariant else JarvisAmber
                            ),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = if (isAccessibilityGranted) "STATUS" else "ENABLE",
                                color = if (isAccessibilityGranted) JarvisCyan else Color.Black,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        // 2. AUTONOMOUS GESTURE DECK
        item {
            Column {
                Text(
                    text = "GLOBAL SYSTEM ACTIONS & GESTURES",
                    color = JarvisCyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    GestureActionButton(
                        title = "HOME",
                        icon = Icons.Default.Home,
                        modifier = Modifier.weight(1f),
                        onClick = { onExecuteGesture(GestureType.HOME) }
                    )
                    GestureActionButton(
                        title = "BACK",
                        icon = Icons.AutoMirrored.Filled.ArrowBack,
                        modifier = Modifier.weight(1f),
                        onClick = { onExecuteGesture(GestureType.BACK) }
                    )
                    GestureActionButton(
                        title = "RECENTS",
                        icon = Icons.Default.ViewCarousel,
                        modifier = Modifier.weight(1f),
                        onClick = { onExecuteGesture(GestureType.RECENTS) }
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    GestureActionButton(
                        title = "NOTIFICATIONS",
                        icon = Icons.Default.Notifications,
                        modifier = Modifier.weight(1f),
                        onClick = { onExecuteGesture(GestureType.NOTIFICATIONS) }
                    )
                    GestureActionButton(
                        title = "LOCK PHONE",
                        icon = Icons.Default.Lock,
                        modifier = Modifier.weight(1f),
                        onClick = { onExecuteGesture(GestureType.LOCK_SCREEN) }
                    )
                    GestureActionButton(
                        title = "SCREENSHOT",
                        icon = Icons.Default.CameraAlt,
                        modifier = Modifier.weight(1f),
                        onClick = { onExecuteGesture(GestureType.SCREENSHOT) }
                    )
                }
            }
        }

        // 3. SYSTEM SETTINGS DIRECT HOOKS
        item {
            Column {
                Text(
                    text = "SYSTEM SETTINGS INTERFACES",
                    color = JarvisCyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SettingShortcutButton(
                        label = "Wi-Fi",
                        icon = Icons.Default.Wifi,
                        modifier = Modifier.weight(1f),
                        onClick = { onOpenSetting("Wi-Fi", android.provider.Settings.ACTION_WIFI_SETTINGS) }
                    )
                    SettingShortcutButton(
                        label = "Bluetooth",
                        icon = Icons.Default.Bluetooth,
                        modifier = Modifier.weight(1f),
                        onClick = { onOpenSetting("Bluetooth", android.provider.Settings.ACTION_BLUETOOTH_SETTINGS) }
                    )
                    SettingShortcutButton(
                        label = "Display",
                        icon = Icons.Default.BrightnessMedium,
                        modifier = Modifier.weight(1f),
                        onClick = { onOpenSetting("Display", android.provider.Settings.ACTION_DISPLAY_SETTINGS) }
                    )
                    SettingShortcutButton(
                        label = "Settings",
                        icon = Icons.Default.Settings,
                        modifier = Modifier.weight(1f),
                        onClick = { onOpenSetting("Settings", android.provider.Settings.ACTION_SETTINGS) }
                    )
                }
            }
        }

        // 4. INSTALLED APPS LAUNCHER (Execute any app on user's phone!)
        item {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "APP LAUNCH MATRIX (${filteredApps.size})",
                        color = JarvisCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "LAUNCH ANY APP",
                        color = JarvisNeonGreen,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Search Box
                OutlinedTextField(
                    value = appSearchQuery,
                    onValueChange = { appSearchQuery = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("app_search_field"),
                    placeholder = {
                        Text(
                            text = "Search app to launch (YouTube, WhatsApp, Camera...)",
                            color = JarvisTextSecondary,
                            fontSize = 12.sp
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = null,
                            tint = JarvisCyan
                        )
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = JarvisCyan,
                        unfocusedBorderColor = JarvisBorderGlow,
                        focusedTextColor = JarvisTextPrimary,
                        unfocusedTextColor = JarvisTextPrimary,
                        focusedContainerColor = JarvisDarkSurface,
                        unfocusedContainerColor = JarvisDarkSurface
                    )
                )
            }
        }

        // List of Apps
        items(filteredApps.take(30), key = { it.packageName }) { app ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onLaunchApp(app.packageName, app.label) }
                    .testTag("app_item_${app.packageName}"),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = JarvisDarkSurface),
                border = BorderStroke(1.dp, JarvisBorderGlow)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(JarvisDarkSurfaceVariant),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Android,
                                contentDescription = null,
                                tint = JarvisCyan,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = app.label,
                                color = JarvisTextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = app.packageName,
                                color = JarvisTextSecondary,
                                fontSize = 11.sp,
                                maxLines = 1
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(JarvisCyan.copy(alpha = 0.15f))
                            .border(1.dp, JarvisCyan.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Launch",
                                tint = JarvisCyan,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "OPEN",
                                color = JarvisCyan,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GestureActionButton(
    title: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .clickable { onClick() }
            .testTag("gesture_btn_$title"),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = JarvisDarkSurface),
        border = BorderStroke(1.dp, JarvisBorderGlow)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp, horizontal = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = JarvisCyan,
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = title,
                color = JarvisTextPrimary,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun SettingShortcutButton(
    label: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier.clickable { onClick() },
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = JarvisDarkSurface),
        border = BorderStroke(1.dp, JarvisBorderGlow)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 10.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = JarvisTextPrimary,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = label,
                color = JarvisTextSecondary,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}
