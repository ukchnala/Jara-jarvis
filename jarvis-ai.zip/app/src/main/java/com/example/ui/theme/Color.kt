package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sci-Fi Jarvis Cyber Palette
val JarvisCyan = Color(0xFF00F0FF)
val JarvisCyanBright = Color(0xFF70F3FF)
val JarvisCyanDim = Color(0xFF00A8B5)
val JarvisElectricBlue = Color(0xFF0077FE)
val JarvisDeepDark = Color(0xFF060911)
val JarvisDarkSurface = Color(0xFF0D1424)
val JarvisDarkSurfaceVariant = Color(0xFF141F36)
val JarvisBorderGlow = Color(0x6600F0FF)
val JarvisAmber = Color(0xFFFFB703)
val JarvisNeonGreen = Color(0xFF06D6A0)
val JarvisAlertRed = Color(0xFFEF476F)
val JarvisTextPrimary = Color(0xFFF0F6FC)
val JarvisTextSecondary = Color(0xFF8B9CB5)
val JarvisGridLine = Color(0x1A00F0FF)
