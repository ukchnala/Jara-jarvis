package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.JarvisAmber
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.JarvisCyanBright
import com.example.ui.theme.JarvisElectricBlue
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun ArcReactorCore(
    modifier: Modifier = Modifier,
    size: Dp = 240.dp,
    isActive: Boolean = true,
    isListening: Boolean = false,
    isSpeaking: Boolean = false,
    audioRms: Float = 0f,
    onClick: () -> Unit = {}
) {
    val infiniteTransition = rememberInfiniteTransition(label = "ReactorTransition")

    // Slow rotation for outer ring
    val outerRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 18000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "outerRot"
    )

    // Counter-rotation for inner segment ring
    val innerRotation by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 9000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "innerRot"
    )

    // Pulse core
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1400, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val activeColor = when {
        isListening -> JarvisCyanBright
        isSpeaking -> JarvisAmber
        isActive -> JarvisCyan
        else -> JarvisElectricBlue
    }

    Box(
        modifier = modifier
            .size(size)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(bounded = false, radius = size / 2),
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.toPx() / 2f, size.toPx() / 2f)
            val maxRadius = size.toPx() / 2f - 12.dp.toPx()

            // 1. Outer Glow Aura
            val dynamicGlowRadius = maxRadius * (if (isListening || isSpeaking) 1.05f + audioRms * 0.15f else pulseScale)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(activeColor.copy(alpha = 0.25f), Color.Transparent),
                    center = center,
                    radius = dynamicGlowRadius
                ),
                radius = dynamicGlowRadius,
                center = center
            )

            // 2. Outer Static Thin Ring
            drawCircle(
                color = activeColor.copy(alpha = 0.35f),
                radius = maxRadius,
                center = center,
                style = Stroke(width = 1.5.dp.toPx())
            )

            // 3. Outer Rotating Dashed Ticks
            rotate(outerRotation, pivot = center) {
                val tickCount = 24
                for (i in 0 until tickCount) {
                    val angle = (i * (360f / tickCount)) * (Math.PI / 180f)
                    val r1 = maxRadius - 2.dp.toPx()
                    val r2 = maxRadius - if (i % 4 == 0) 10.dp.toPx() else 5.dp.toPx()
                    val start = Offset(
                        center.x + r1 * cos(angle).toFloat(),
                        center.y + r1 * sin(angle).toFloat()
                    )
                    val end = Offset(
                        center.x + r2 * cos(angle).toFloat(),
                        center.y + r2 * sin(angle).toFloat()
                    )
                    drawLine(
                        color = if (i % 4 == 0) activeColor else activeColor.copy(alpha = 0.4f),
                        start = start,
                        end = end,
                        strokeWidth = if (i % 4 == 0) 2.dp.toPx() else 1.dp.toPx()
                    )
                }
            }

            // 4. Middle Arc Segment Ring
            rotate(innerRotation, pivot = center) {
                val middleRadius = maxRadius * 0.72f
                val segments = 8
                val sweep = 30f
                for (s in 0 until segments) {
                    val startAngle = s * (360f / segments)
                    drawArc(
                        color = activeColor.copy(alpha = 0.75f),
                        startAngle = startAngle,
                        sweepAngle = sweep,
                        useCenter = false,
                        topLeft = Offset(center.x - middleRadius, center.y - middleRadius),
                        size = androidx.compose.ui.geometry.Size(middleRadius * 2, middleRadius * 2),
                        style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
            }

            // 5. Inner Core Ring
            val innerRadius = maxRadius * 0.45f * (if (isListening || isSpeaking) 1f + audioRms * 0.2f else pulseScale)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        activeColor,
                        activeColor.copy(alpha = 0.8f),
                        activeColor.copy(alpha = 0.1f)
                    ),
                    center = center,
                    radius = innerRadius
                ),
                radius = innerRadius,
                center = center
            )

            // 6. Central Triangle / Arc Reactor Emblem
            val coreTriangleRadius = innerRadius * 0.55f
            rotate(outerRotation * 0.5f, pivot = center) {
                val points = listOf(
                    Offset(center.x, center.y - coreTriangleRadius),
                    Offset(
                        center.x + coreTriangleRadius * cos(Math.PI / 6).toFloat(),
                        center.y + coreTriangleRadius * sin(Math.PI / 6).toFloat()
                    ),
                    Offset(
                        center.x - coreTriangleRadius * cos(Math.PI / 6).toFloat(),
                        center.y + coreTriangleRadius * sin(Math.PI / 6).toFloat()
                    )
                )
                for (k in points.indices) {
                    val next = points[(k + 1) % points.size]
                    drawLine(
                        color = Color.White,
                        start = points[k],
                        end = next,
                        strokeWidth = 2.5.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                }
            }

            // Central bright dot
            drawCircle(
                color = Color.White,
                radius = 4.dp.toPx(),
                center = center
            )
        }
    }
}
