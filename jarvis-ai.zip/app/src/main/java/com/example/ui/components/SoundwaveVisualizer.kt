package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.JarvisAmber
import com.example.ui.theme.JarvisCyan
import kotlin.math.sin

@Composable
fun SoundwaveVisualizer(
    modifier: Modifier = Modifier,
    height: Dp = 48.dp,
    isActive: Boolean = false,
    audioRms: Float = 0f,
    isSpeaking: Boolean = false
) {
    val infiniteTransition = rememberInfiniteTransition(label = "waveAnim")

    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 6.28f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wavePhase"
    )

    val color = if (isSpeaking) JarvisAmber else JarvisCyan

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(height)
    ) {
        val width = size.width
        val midY = size.height / 2f
        val barCount = 36
        val barSpacing = width / (barCount + 1)

        for (i in 0 until barCount) {
            val x = (i + 1) * barSpacing
            val factor = sin(phase + i * 0.35f)

            val baseHeight = if (isActive) {
                val rmsBonus = audioRms * 28.dp.toPx()
                (8.dp.toPx() + (factor + 1f) * 10.dp.toPx() + rmsBonus).coerceAtMost(size.height * 0.9f)
            } else {
                3.dp.toPx()
            }

            val start = Offset(x, midY - baseHeight / 2f)
            val end = Offset(x, midY + baseHeight / 2f)

            drawLine(
                color = color.copy(alpha = if (isActive) 0.85f else 0.3f),
                start = start,
                end = end,
                strokeWidth = 3.dp.toPx(),
                cap = StrokeCap.Round
            )
        }
    }
}
