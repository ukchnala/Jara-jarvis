package com.example.ui.screens

import android.Manifest
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.ui.components.QrCodeDialog
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.JarvisAmber
import com.example.ui.theme.JarvisBorderGlow
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.JarvisDarkSurface
import com.example.ui.theme.JarvisDarkSurfaceVariant
import com.example.ui.theme.JarvisDeepDark
import com.example.ui.theme.JarvisNeonGreen
import com.example.ui.theme.JarvisTextPrimary
import com.example.ui.theme.JarvisTextSecondary
import com.example.viewmodel.JarvisTab
import com.example.viewmodel.JarvisViewModel

data class NavItem(
    val tab: JarvisTab,
    val title: String,
    val icon: ImageVector,
    val tag: String
)

@Composable
fun JarvisMainContainer(
    viewModel: JarvisViewModel
) {
    val activeTab by viewModel.activeTab.collectAsState()
    val phoneControlEnabled by viewModel.phoneControlEnabled.collectAsState()
    val isAccessibilityGranted by viewModel.isAccessibilityGranted.collectAsState()
    val messages by viewModel.messages.collectAsState()
    val systemLogs by viewModel.systemLogs.collectAsState()
    val batteryLevel by viewModel.batteryLevel.collectAsState()
    val isCharging by viewModel.isCharging.collectAsState()
    val isFlashlightOn by viewModel.isFlashlightOn.collectAsState()
    val installedApps by viewModel.installedApps.collectAsState()
    val isVoiceAutoSpeakEnabled by viewModel.voiceAutoSpeakEnabled.collectAsState()
    val isListening by viewModel.isListening.collectAsState()
    val isSpeaking by viewModel.isSpeaking.collectAsState()
    val audioRms by viewModel.rmsDb.collectAsState()
    val isBackgroundListeningEnabled by viewModel.isBackgroundListeningEnabled.collectAsState()

    // Runtime Permission Request for Audio & Camera
    val permissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val audioGranted = permissions[Manifest.permission.RECORD_AUDIO] ?: false
        if (audioGranted) {
            viewModel.addSystemLog("PERMISSION: Audio Record Granted")
        }
    }

    LaunchedEffect(Unit) {
        permissionsLauncher.launch(
            arrayOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.CAMERA
            )
        )
    }

    var showQrDialog by remember { mutableStateOf(false) }

    if (showQrDialog) {
        QrCodeDialog(onDismissRequest = { showQrDialog = false })
    }

    // BackHandler to return to Core HUD if user presses Android back from any sub-screen
    BackHandler(enabled = activeTab != JarvisTab.CORE_HUD) {
        viewModel.selectTab(JarvisTab.CORE_HUD)
    }

    val navItems = listOf(
        NavItem(JarvisTab.CORE_HUD, "HUD", Icons.Default.Dashboard, "nav_hud"),
        NavItem(JarvisTab.VOICE_CHAT, "VOICE / CHAT", Icons.Default.Chat, "nav_chat"),
        NavItem(JarvisTab.PHONE_CONTROL, "CONTROL", Icons.Default.PhoneAndroid, "nav_control"),
        NavItem(JarvisTab.SYSTEM_LOGS, "LOGS", Icons.Default.Terminal, "nav_logs")
    )

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(JarvisDeepDark),
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(JarvisDarkSurface)
                    .windowInsetsPadding(WindowInsets.statusBars)
                    .border(1.dp, JarvisBorderGlow)
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Holographic Status Dot
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .clip(CircleShape)
                            .background(if (phoneControlEnabled) JarvisNeonGreen else JarvisCyan)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "J.A.R.V.I.S.",
                            color = JarvisCyan,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 2.sp
                        )
                        Text(
                            text = if (phoneControlEnabled) "AUTONOMOUS PHONE CONTROL ACTIVE" else "AI ASSISTANT STANDBY",
                            color = if (phoneControlEnabled) JarvisNeonGreen else JarvisTextSecondary,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // QR Code Phone Download Action Button
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(JarvisCyan.copy(alpha = 0.15f))
                            .border(1.dp, JarvisCyan, RoundedCornerShape(8.dp))
                            .clickable { showQrDialog = true }
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                            .testTag("open_qr_dialog_topbar_btn")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.QrCode,
                                contentDescription = "Download QR",
                                tint = JarvisCyan,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "GET APP",
                                color = JarvisCyan,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Security Protocol Badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (phoneControlEnabled) JarvisNeonGreen.copy(alpha = 0.2f) else JarvisDarkSurfaceVariant)
                            .border(
                                1.dp,
                                if (phoneControlEnabled) JarvisNeonGreen.copy(alpha = 0.6f) else JarvisBorderGlow,
                                RoundedCornerShape(12.dp)
                            )
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = if (phoneControlEnabled) "FULL ACCESS" else "STANDARD",
                            color = if (phoneControlEnabled) JarvisNeonGreen else JarvisCyan,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        },
        bottomBar = {
            NavigationBar(
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .border(1.dp, JarvisBorderGlow),
                containerColor = JarvisDarkSurface,
                contentColor = JarvisCyan
            ) {
                navItems.forEach { item ->
                    val selected = activeTab == item.tab
                    NavigationBarItem(
                        selected = selected,
                        onClick = { viewModel.selectTab(item.tab) },
                        modifier = Modifier.testTag(item.tag),
                        icon = {
                            Icon(
                                imageVector = item.icon,
                                contentDescription = item.title,
                                modifier = Modifier.size(22.dp)
                            )
                        },
                        label = {
                            Text(
                                text = item.title,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.Black,
                            selectedTextColor = JarvisCyan,
                            indicatorColor = JarvisCyan,
                            unselectedIconColor = JarvisTextSecondary,
                            unselectedTextColor = JarvisTextSecondary
                        )
                    )
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            Crossfade(targetState = activeTab, label = "tabTransition") { tab ->
                when (tab) {
                    JarvisTab.CORE_HUD -> CoreHudScreen(
                        phoneControlEnabled = phoneControlEnabled,
                        isAccessibilityGranted = isAccessibilityGranted,
                        isBackgroundListeningEnabled = isBackgroundListeningEnabled,
                        batteryLevel = batteryLevel,
                        isCharging = isCharging,
                        isFlashlightOn = isFlashlightOn,
                        isListening = isListening,
                        isSpeaking = isSpeaking,
                        audioRms = audioRms,
                        installedAppCount = installedApps.size,
                        onTogglePhoneControl = { viewModel.setPhoneControlEnabled(it) },
                        onToggleBackgroundListening = { viewModel.toggleBackgroundListening(it) },
                        onReactorTap = { viewModel.onReactorCoreClicked() },
                        onOpenAccessibility = { viewModel.openAccessibilitySettings() },
                        onToggleFlashlight = { viewModel.toggleFlashlight() },
                        onAdjustVolume = { viewModel.processUserCommand(if (it) "Volume up" else "Volume down") },
                        onExecuteGesture = { viewModel.executeGesture(it) },
                        onStartVoice = { viewModel.startListening() },
                        onStopVoice = { viewModel.stopListening() },
                        onQuickPrompt = { viewModel.processUserCommand(it) },
                        onOpenQrDialog = { showQrDialog = true },
                        onTestWakeWord = { viewModel.triggerWakeWordTest() }
                    )

                    JarvisTab.VOICE_CHAT -> VoiceChatScreen(
                        messages = messages,
                        isListening = isListening,
                        isSpeaking = isSpeaking,
                        audioRms = audioRms,
                        isVoiceAutoSpeakEnabled = isVoiceAutoSpeakEnabled,
                        phoneControlEnabled = phoneControlEnabled,
                        onSendMessage = { viewModel.processUserCommand(it) },
                        onStartVoice = { viewModel.startListening() },
                        onStopVoice = { viewModel.stopListening() },
                        onToggleAutoSpeak = { viewModel.toggleVoiceAutoSpeak() },
                        onClearChat = { viewModel.clearChat() }
                    )

                    JarvisTab.PHONE_CONTROL -> PhoneControlScreen(
                        phoneControlEnabled = phoneControlEnabled,
                        isAccessibilityGranted = isAccessibilityGranted,
                        installedApps = installedApps,
                        onTogglePhoneControl = { viewModel.setPhoneControlEnabled(it) },
                        onOpenAccessibilitySettings = { viewModel.openAccessibilitySettings() },
                        onExecuteGesture = { viewModel.executeGesture(it) },
                        onLaunchApp = { pkg, label -> viewModel.launchAppByPackage(pkg, label) },
                        onOpenSetting = { _, intentAction ->
                            viewModel.executeGesture(com.example.model.GestureType.HOME)
                            viewModel.processUserCommand("Settings kholo")
                        }
                    )

                    JarvisTab.SYSTEM_LOGS -> SystemLogsScreen(
                        logs = systemLogs,
                        phoneControlEnabled = phoneControlEnabled
                    )
                }
            }
        }
    }
}
