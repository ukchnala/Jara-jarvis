package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val JarvisDarkColorScheme = darkColorScheme(
    primary = JarvisCyan,
    onPrimary = Color.Black,
    primaryContainer = JarvisDarkSurfaceVariant,
    onPrimaryContainer = JarvisCyanBright,
    secondary = JarvisElectricBlue,
    onSecondary = Color.White,
    secondaryContainer = JarvisDarkSurface,
    onSecondaryContainer = JarvisCyan,
    tertiary = JarvisAmber,
    onTertiary = Color.Black,
    background = JarvisDeepDark,
    onBackground = JarvisTextPrimary,
    surface = JarvisDarkSurface,
    onSurface = JarvisTextPrimary,
    surfaceVariant = JarvisDarkSurfaceVariant,
    onSurfaceVariant = JarvisTextSecondary,
    error = JarvisAlertRed,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false, // Keep sci-fi Jarvis aesthetic consistent
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = JarvisDarkColorScheme,
        typography = Typography,
        content = content
    )
}
