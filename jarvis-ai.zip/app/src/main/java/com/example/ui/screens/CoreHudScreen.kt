package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Accessibility
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.BatteryStd
import androidx.compose.material.icons.filled.FlashlightOff
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.ViewCarousel
import androidx.compose.material.icons.filled.VolumeDown
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.filled.QrCode
import com.example.model.GestureType
import com.example.ui.components.ArcReactorCore
import com.example.ui.components.CyberCard
import com.example.ui.components.CyberStatusBadge
import com.example.ui.components.HudMetricItem
import com.example.ui.components.SoundwaveVisualizer
import com.example.ui.theme.JarvisAlertRed
import com.example.ui.theme.JarvisAmber
import com.example.ui.theme.JarvisBorderGlow
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.JarvisCyanBright
import com.example.ui.theme.JarvisDarkSurface
import com.example.ui.theme.JarvisDarkSurfaceVariant
import com.example.ui.theme.JarvisDeepDark
import com.example.ui.theme.JarvisNeonGreen
import com.example.ui.theme.JarvisTextPrimary
import com.example.ui.theme.JarvisTextSecondary

@Composable
fun CoreHudScreen(
    phoneControlEnabled: Boolean,
    isAccessibilityGranted: Boolean,
    batteryLevel: Int,
    isCharging: Boolean,
    isFlashlightOn: Boolean,
    isListening: Boolean,
    isSpeaking: Boolean,
    audioRms: Float,
    installedAppCount: Int,
    isBackgroundListeningEnabled: Boolean = false,
    onTogglePhoneControl: (Boolean) -> Unit,
    onToggleBackgroundListening: (Boolean) -> Unit = {},
    onReactorTap: () -> Unit = {},
    onOpenAccessibility: () -> Unit,
    onToggleFlashlight: () -> Unit,
    onAdjustVolume: (Boolean) -> Unit,
    onExecuteGesture: (GestureType) -> Unit,
    onStartVoice: () -> Unit,
    onStopVoice: () -> Unit,
    onQuickPrompt: (String) -> Unit,
    onOpenQrDialog: () -> Unit = {},
    onTestWakeWord: () -> Unit = {}
) {
    val quickPrompts = listOf(
        "Hey Jarvis",
        "YouTube kholo",
        "Camera kholo",
        "Flashlight on karo",
        "Home screen par jao",
        "Battery kitni hai?",
        "Recent apps dikhao",
        "Volume badhao",
        "Screen lock karo"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(JarvisDeepDark)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Top HUD Diagnostics Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                HudMetricItem(
                    title = "Battery",
                    value = "$batteryLevel% ${if (isCharging) "⚡" else ""}",
                    icon = if (isCharging) Icons.Default.BatteryChargingFull else Icons.Default.BatteryStd,
                    accentColor = if (batteryLevel < 20) JarvisAlertRed else JarvisCyan,
                    modifier = Modifier.weight(1f)
                )

                HudMetricItem(
                    title = "Apps Ready",
                    value = "$installedAppCount APPS",
                    icon = Icons.Default.PhoneAndroid,
                    accentColor = JarvisNeonGreen,
                    modifier = Modifier.weight(1f)
                )

                HudMetricItem(
                    title = "Security",
                    value = if (phoneControlEnabled) "AUTONOMOUS" else "STANDBY",
                    icon = Icons.Default.Security,
                    accentColor = if (phoneControlEnabled) JarvisNeonGreen else JarvisAmber,
                    modifier = Modifier.weight(1.2f)
                )
            }
        }

        // Phone QR Code Scanner Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenQrDialog() }
                    .testTag("hud_qr_code_card"),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = JarvisDarkSurface),
                border = BorderStroke(1.dp, JarvisCyan)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(JarvisCyan.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.QrCode,
                                contentDescription = "QR Code",
                                tint = JarvisCyan,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "INSTALL ON PHONE (QR)",
                                color = JarvisCyan,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "Scan to download or open on your device",
                                color = JarvisTextSecondary,
                                fontSize = 10.sp
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(JarvisCyan)
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "SCAN QR",
                            color = Color.Black,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        // 2. MASTER PHONE CONTROL SWITCH (The core feature requested by the user!)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("master_phone_control_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (phoneControlEnabled) JarvisDarkSurfaceVariant else JarvisDarkSurface
                ),
                border = BorderStroke(
                    width = if (phoneControlEnabled) 2.dp else 1.dp,
                    color = if (phoneControlEnabled) JarvisNeonGreen else JarvisBorderGlow
                )
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (phoneControlEnabled) JarvisNeonGreen.copy(alpha = 0.2f)
                                        else JarvisCyan.copy(alpha = 0.15f)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PhoneAndroid,
                                    contentDescription = null,
                                    tint = if (phoneControlEnabled) JarvisNeonGreen else JarvisCyan,
                                    modifier = Modifier.size(26.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "PHONE CONTROL",
                                    color = JarvisTextPrimary,
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontFamily = FontFamily.Monospace,
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = if (phoneControlEnabled) "Full Autonomous Authority: ACTIVE" else "Manual Authority: OFF",
                                    color = if (phoneControlEnabled) JarvisNeonGreen else JarvisTextSecondary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }

                        Switch(
                            checked = phoneControlEnabled,
                            onCheckedChange = onTogglePhoneControl,
                            modifier = Modifier.testTag("phone_control_switch"),
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.Black,
                                checkedTrackColor = JarvisNeonGreen,
                                uncheckedThumbColor = JarvisTextSecondary,
                                uncheckedTrackColor = JarvisDarkSurfaceVariant
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = if (phoneControlEnabled)
                            "JARVIS has full system authority to open any app, perform screen gestures (Home, Back, Recents, Notifications), adjust volume, torch, and control device subsystems autonomously."
                        else
                            "Turn this ON to grant JARVIS full control over your phone. Jarvis can then open any app, control device hardware, and execute commands automatically.",
                        color = JarvisTextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )

                    // Accessibility Bridge status banner
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(JarvisDeepDark)
                            .border(1.dp, if (isAccessibilityGranted) JarvisNeonGreen.copy(alpha = 0.3f) else JarvisAmber.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Accessibility,
                                contentDescription = null,
                                tint = if (isAccessibilityGranted) JarvisNeonGreen else JarvisAmber,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "System Accessibility Bridge",
                                    color = JarvisTextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = if (isAccessibilityGranted) "Service Connected" else "Service Permission Needed",
                                    color = if (isAccessibilityGranted) JarvisNeonGreen else JarvisAmber,
                                    fontSize = 10.sp
                                )
                            }
                        }

                        if (!isAccessibilityGranted) {
                            Button(
                                onClick = onOpenAccessibility,
                                modifier = Modifier
                                    .height(32.dp)
                                    .testTag("enable_accessibility_button"),
                                colors = ButtonDefaults.buttonColors(containerColor = JarvisAmber),
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp)
                            ) {
                                Text(
                                    text = "ENABLE",
                                    color = Color.Black,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }
        }

        // 3. BACKGROUND LISTENING ('HEY JARVIS' WAKE WORD) SWITCH
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("background_listening_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isBackgroundListeningEnabled) JarvisDarkSurfaceVariant else JarvisDarkSurface
                ),
                border = BorderStroke(
                    width = if (isBackgroundListeningEnabled) 2.dp else 1.dp,
                    color = if (isBackgroundListeningEnabled) JarvisAmber else JarvisBorderGlow
                )
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (isBackgroundListeningEnabled) JarvisAmber.copy(alpha = 0.2f)
                                        else JarvisCyan.copy(alpha = 0.15f)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Hearing,
                                    contentDescription = null,
                                    tint = if (isBackgroundListeningEnabled) JarvisAmber else JarvisCyan,
                                    modifier = Modifier.size(26.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "BACKGROUND LISTENING",
                                    color = JarvisTextPrimary,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontFamily = FontFamily.Monospace,
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = if (isBackgroundListeningEnabled) "Wake Word: 'Jarvis' (ACTIVE)" else "Background Listener: OFF",
                                    color = if (isBackgroundListeningEnabled) JarvisAmber else JarvisTextSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }

                        Switch(
                            checked = isBackgroundListeningEnabled,
                            onCheckedChange = onToggleBackgroundListening,
                            modifier = Modifier.testTag("background_listening_switch"),
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.Black,
                                checkedTrackColor = JarvisAmber,
                                uncheckedThumbColor = JarvisTextSecondary,
                                uncheckedTrackColor = JarvisDarkSurfaceVariant
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = if (isBackgroundListeningEnabled)
                            "JARVIS background service chal rahi hai! Chahe app band ho ya screen lock ho, 'Jarvis' bolte hi main activate hokar Hindi mein baat karunga aur phone control karunga."
                        else
                            "Ise ON karein taaki app band hone par bhi 'Jarvis' bolne par Jarvis activate ho sake aur pure phone ko control kar sake.",
                        color = JarvisTextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = onTestWakeWord,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(40.dp)
                            .testTag("test_wake_word_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = JarvisAmber.copy(alpha = 0.2f)),
                        border = BorderStroke(1.dp, JarvisAmber),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Hearing,
                            contentDescription = null,
                            tint = JarvisAmber,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "TEST WAKE WORD ('HEY JARVIS')",
                            color = JarvisAmber,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }
        }

        // 4. ARC REACTOR HERO CORE & SOUNDWAVE
        item {
            CyberCard {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CyberStatusBadge(
                            label = if (isListening) "LISTENING..." else if (isSpeaking) "SPEAKING..." else "CORE ONLINE",
                            isActive = isListening || isSpeaking || phoneControlEnabled,
                            activeColor = if (isListening) JarvisCyanBright else if (isSpeaking) JarvisAmber else JarvisCyan
                        )

                        Text(
                            text = "MARK VII ARC REACTOR",
                            color = JarvisTextSecondary,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 1.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Arc Reactor with click to speak
                    ArcReactorCore(
                        size = 210.dp,
                        isActive = phoneControlEnabled,
                        isListening = isListening,
                        isSpeaking = isSpeaking,
                        audioRms = audioRms,
                        onClick = onReactorTap
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Live Soundwave
                    SoundwaveVisualizer(
                        modifier = Modifier.padding(horizontal = 16.dp),
                        height = 36.dp,
                        isActive = isListening || isSpeaking,
                        audioRms = audioRms,
                        isSpeaking = isSpeaking
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = if (isListening) "Main sun raha hoon... Bol kar ruk jayen" else if (isSpeaking) "Jarvis bol raha hai..." else "Icon par tap karein aur Jarvis se baat karein",
                        color = if (isListening) JarvisCyanBright else if (isSpeaking) JarvisAmber else JarvisCyan,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // 4. QUICK HARDWARE TELEMETRY CONTROLS
        item {
            Column {
                Text(
                    text = "DEVICE TELEMETRY & HARDWARE",
                    color = JarvisCyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Flashlight
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onToggleFlashlight() }
                            .testTag("quick_toggle_torch"),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isFlashlightOn) JarvisAmber.copy(alpha = 0.25f) else JarvisDarkSurface
                        ),
                        border = BorderStroke(1.dp, if (isFlashlightOn) JarvisAmber else JarvisBorderGlow)
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = if (isFlashlightOn) Icons.Default.FlashlightOn else Icons.Default.FlashlightOff,
                                contentDescription = "Flashlight",
                                tint = if (isFlashlightOn) JarvisAmber else JarvisTextSecondary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "TORCH",
                                color = JarvisTextPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = if (isFlashlightOn) "ON" else "OFF",
                                color = if (isFlashlightOn) JarvisAmber else JarvisTextSecondary,
                                fontSize = 10.sp
                            )
                        }
                    }

                    // Volume Up
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onAdjustVolume(true) }
                            .testTag("quick_volume_up"),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = JarvisDarkSurface),
                        border = BorderStroke(1.dp, JarvisBorderGlow)
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.VolumeUp,
                                contentDescription = "Volume Up",
                                tint = JarvisCyan,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "VOLUME",
                                color = JarvisTextPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "+ BOOST",
                                color = JarvisCyan,
                                fontSize = 10.sp
                            )
                        }
                    }

                    // Volume Down
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onAdjustVolume(false) }
                            .testTag("quick_volume_down"),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = JarvisDarkSurface),
                        border = BorderStroke(1.dp, JarvisBorderGlow)
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.VolumeDown,
                                contentDescription = "Volume Down",
                                tint = JarvisCyan,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "VOLUME",
                                color = JarvisTextPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "- REDUCE",
                                color = JarvisCyan,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }
        }

        // 5. AUTONOMOUS GESTURE BAR
        item {
            Column {
                Text(
                    text = "AUTONOMOUS SYSTEM GESTURES",
                    color = JarvisCyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    GestureMiniButton(
                        label = "HOME",
                        icon = Icons.Default.Home,
                        modifier = Modifier.weight(1f),
                        onClick = { onExecuteGesture(GestureType.HOME) }
                    )
                    GestureMiniButton(
                        label = "RECENTS",
                        icon = Icons.Default.ViewCarousel,
                        modifier = Modifier.weight(1f),
                        onClick = { onExecuteGesture(GestureType.RECENTS) }
                    )
                    GestureMiniButton(
                        label = "LOCK",
                        icon = Icons.Default.Lock,
                        modifier = Modifier.weight(1f),
                        onClick = { onExecuteGesture(GestureType.LOCK_SCREEN) }
                    )
                }
            }
        }

        // 6. QUICK PROMPTS CHIPS
        item {
            Column {
                Text(
                    text = "VOICE COMMAND PRESETS (HINDI & ENGLISH)",
                    color = JarvisCyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(horizontal = 0.dp)
                ) {
                    items(quickPrompts) { prompt ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(JarvisDarkSurfaceVariant)
                                .border(1.dp, JarvisBorderGlow, RoundedCornerShape(20.dp))
                                .clickable { onQuickPrompt(prompt) }
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = prompt,
                                color = JarvisTextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GestureMiniButton(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier.clickable { onClick() },
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = JarvisDarkSurface),
        border = BorderStroke(1.dp, JarvisBorderGlow)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 10.dp, horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = JarvisCyan,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                color = JarvisTextPrimary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}
